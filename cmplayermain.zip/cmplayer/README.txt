CMPlayer WordPress Plugin (Basic Skeleton)
==========================================
1. Copy the `cmplayer` folder into your site's `wp-content/plugins/` directory.
2. Go to WordPress admin > Plugins, activate 'CMPlayer'.
3. Use shortcode [cmplayer] in any post/page to show video player.
4. Admin panel available at Dashboard > CMPlayer.
5. Next steps: Add more features as per guide.